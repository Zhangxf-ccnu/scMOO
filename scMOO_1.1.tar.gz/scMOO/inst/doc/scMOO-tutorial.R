## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, eval=FALSE---------------------------------------------------
#  install.packages("devtools")

## ----install, eval=FALSE-------------------------------------------------
#  devtools::install_github("Zhangxf-ccnu/scMOO", subdir="pkg")

## ----scmoo, eval=FALSE---------------------------------------------------
#  library(scMOO)
#  data(PBMC_CL)
#  result <- scMOO(PBMC_CL, percent=0, verbose=TRUE, estimates.only=FALSE)

## ----hvgs, eval=FALSE----------------------------------------------------
#  library(Seurat)
#  x.seurat <- CreateSeuratObject(raw_data) ## colnames of data are ture cell labels
#  x.seurat <- NormalizeData(x.seurat)
#  x.seurat <- ScaleData(x.seurat)
#  x.seurat <- FindVariableFeatures(x.seurat, verbose = FALSE)
#  
#  filter_ID <- x.seurat@assays$RNA@var.features
#  data_hvgs <- data[filter_ID,]

## ----imputation, eval=FALSE----------------------------------------------
#  library(scMOO)
#  result <- scMOO(PBMC_CL,  percent=0, estimate.only=TRUE)

## ----sc3, eval=FALSE-----------------------------------------------------
#  library(SingleCellExperiment)
#  library(SC3)
#  library(mclust)
#  library(aricode)
#  
#  sce <- SingleCellExperiment(
#    assays = list(
#      counts = as.matrix(result),
#      logcounts = log2(as.matrix(result) + 1)
#    ),
#    colData = colnames(result)
#  )
#  
#  
#  rowData(sce)$feature_symbol <- rownames(sce)
#  
#  label <- colnames(result)
#  
#  K <- length(unique(label))
#  
#  
#  result <- sc3(sce, ks = K, gene_filter = FALSE)
#  
#  ARI <- adjustedRandIndex(label, result@colData@listData$sc3_6_clusters) #### '6' in 'sc3_6_clusters' is consistant, and equals to the number of cell types
#  
#  NMI <- NMI(result@colData@listData$sc3_6_clusters, label)
#  

## ----seurat, eval=FALSE--------------------------------------------------
#  library(Seurat)
#  x.seurat <- CreateSeuratObject(result)
#  x.seurat <- NormalizeData(x.seurat)
#  x.seurat <- ScaleData(x.seurat)
#  x.seurat <- FindVariableFeatures(x.seurat, verbose = FALSE)
#  
#  x.seurat <- RunPCA(x.seurat, features = VariableFeatures(object = x.seurat))
#  x.seurat <- JackStraw(x.seurat, num.replicate = 100)
#  x.seurat <- ScoreJackStraw(x.seurat, dims = 1:20)
#  x.seurat <- FindNeighbors(x.seurat, dims = 1:10)
#  x.seurat <- FindClusters(x.seurat, resolution = 0.5)
#  
#  label <- colnames(result)
#  
#  ARI <- adjustedRandIndex(as.factor(label), x.seurat$seurat_clusters)
#  
#  NMI <- NMI(x.seurat$seurat_clusters, as.factor(label))

